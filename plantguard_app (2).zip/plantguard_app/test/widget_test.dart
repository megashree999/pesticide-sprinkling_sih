import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:plantguard_app/main.dart';

void main() {
  testWidgets('PlantGuard counter increments smoke test',
      (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const PlantGuardApp());

    // Verify that our app starts correctly
    expect(find.byType(MaterialApp), findsOneWidget);
    expect(find.text('PlantGuard'), findsOneWidget);
    expect(find.text('Smart Plant Protection'), findsOneWidget);

    // Verify buttons are present
    expect(find.byType(ElevatedButton), findsNWidgets(2)); // At least 2 buttons

    // Test navigation to predict screen
    await tester.tap(find.text('Predict Disease'));
    await tester.pumpAndSettle();

    expect(find.text('Predict Disease'), findsOneWidget);
    expect(find.text('Coming Soon!'), findsOneWidget);
  });
}
